package TestComponents;

public class BaseTest {
}
